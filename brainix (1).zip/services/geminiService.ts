
import { GoogleGenAI, Part, Modality } from "@google/genai";
import { HistoryItem, Source } from "../types";

// FIX: Initialize GoogleGenAI with apiKey from environment variables, assuming it's set.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

export const generateText = async (prompt: string, history: HistoryItem[]): Promise<string> => {
  try {
    // FIX: Use ai.chats.create for conversational text generation to maintain history.
    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      history: history,
    });
    const response = await chat.sendMessage({ message: prompt });
    // FIX: Use response.text to extract the generated text.
    return response.text;
  } catch (error) {
    console.error("Error generating text:", error);
    throw new Error("Failed to generate text response.");
  }
};

export const generateImage = async (prompt: string): Promise<string | null> => {
  try {
    // FIX: Switched to gemini-2.5-flash-image model for better general-purpose image generation and prompt understanding.
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [{ text: prompt }],
      },
      config: {
        responseModalities: [Modality.IMAGE],
      },
    });

    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) {
        const base64ImageBytes: string = part.inlineData.data;
        const mimeType = part.inlineData.mimeType;
        return `data:${mimeType};base64,${base64ImageBytes}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Error generating image:", error);
    return null;
  }
};

export const generateCode = async (prompt: string): Promise<string> => {
    try {
        // FIX: Use gemini-2.5-pro for complex tasks like code generation.
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-pro',
            contents: `Please generate only code for the following prompt, without any explanation or markdown formatting. \nPrompt: ${prompt}`
        });
        // FIX: Use response.text to extract the text.
        let code = response.text;
        // Clean up markdown code fences if they exist
        code = code.replace(/^```(?:\w*\n)?/, '').replace(/```$/, '');
        return code.trim();
    } catch (error) {
        console.error("Error generating code:", error);
        throw new Error("Failed to generate code.");
    }
};

export const generatePlan = async (prompt: string, history: HistoryItem[]): Promise<string> => {
  try {
    // FIX: Use ai.chats.create for conversational context in planning.
    const chat = ai.chats.create({
      model: 'gemini-2.5-flash',
      history: history,
      config: {
          systemInstruction: 'You are a helpful planning assistant. Generate clear, concise, and actionable plans.',
      }
    });
    const response = await chat.sendMessage({ message: prompt });
    // FIX: Use response.text to extract the text.
    return response.text;
  } catch (error)    {
    console.error("Error generating plan:", error);
    throw new Error("Failed to generate plan.");
  }
};

export const searchWeb = async (prompt: string): Promise<{ text: string, sources: Source[] }> => {
  try {
    // FIX: Use the googleSearch tool for web-grounded responses.
    const response = await ai.models.generateContent({
       model: "gemini-2.5-flash",
       contents: prompt,
       config: {
         tools: [{googleSearch: {}}],
       },
    });
    
    // FIX: Use response.text to extract text and extract sources from groundingMetadata.
    const text = response.text;
    const sources: Source[] = response.candidates?.[0]?.groundingMetadata?.groundingChunks
      ?.map((chunk: any) => chunk.web)
      .filter(Boolean)
      .map((web: any) => ({ uri: web.uri, title: web.title })) || [];
      
    return { text, sources };
  } catch (error) {
    console.error("Error searching web:", error);
    throw new Error("Failed to search the web.");
  }
};

export const generateAnswerFromContext = async (
    question: string,
    context: { text?: string; image?: { mimeType: string; data: string } }
  ): Promise<string> => {
    try {
      const parts: Part[] = [];
  
      if (context.image) {
        parts.push({
          inlineData: {
            mimeType: context.image.mimeType,
            data: context.image.data,
          },
        });
      }
  
      let fullPrompt = question;
      if (context.text) {
        fullPrompt = `Context:\n---\n${context.text}\n---\nQuestion: ${question}`;
      }
      parts.push({ text: fullPrompt });
      
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: parts },
      });
  
      return response.text;
    } catch (error) {
      console.error("Error generating answer from context:", error);
      throw new Error("Failed to generate answer from context.");
    }
  };
