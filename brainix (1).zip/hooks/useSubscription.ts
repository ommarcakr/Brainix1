// FIX: Added full content for hooks/useSubscription.ts, implementing the subscription logic.
import { useState, useEffect, useCallback } from 'react';
import { Subscription, SubscriptionHook } from '../types';

const DAILY_FREE_LIMIT = 3;

// Predefined list of activation codes
const PREDEFINED_CODES = new Set([
  'SAKR-1A9F-B72X-LQ10', 'SAKR-9ZQW-KT55-PL88', 'SAKR-5MNV-2JX3-AQ44', 'SAKR-3BHF-9K22-ZW17',
  'SAKR-8TYP-QX66-DR09', 'SAKR-7LWM-PK10-BR50', 'SAKR-2AZN-MY55-TC90', 'SAKR-4QWE-8RTP-HN33',
  'SAKR-9KJU-1YGH-VB44', 'SAKR-6PLD-3AQZ-TY11', 'SAKR-5GHN-4MKO-ED72', 'SAKR-2BVX-8LKJ-NM20',
  'SAKR-1ZXC-7POI-LM55', 'SAKR-9TRE-2WQA-JK88', 'SAKR-3VBN-4YUI-RT60', 'SAKR-8DFG-5HJK-ZX91',
  'SAKR-7LPO-9MNB-QA12', 'SAKR-2WER-6TYU-IO34', 'SAKR-4ASD-8FGH-JK56', 'SAKR-9QWE-3RTY-UI78',
  'SAKR-6DFG-5HJK-LZ90', 'SAKR-1XCV-8BNM-OP23', 'SAKR-7RTY-4UIO-AS45', 'SAKR-3GHJ-9KLZ-XC67',
  'SAKR-8POI-2WER-QA89', 'SAKR-5TYU-6IOP-MN10', 'SAKR-2FGH-3JKL-VD22', 'SAKR-1ZXC-4VBN-TR33',
  'SAKR-9MNB-8QWE-PL44', 'SAKR-7ASD-6RTY-GH55', 'SAKR-3FGH-2JKL-QZ66', 'SAKR-8UIO-5PAS-LM77',
  'SAKR-4XCV-1BNM-WE88', 'SAKR-6PLM-9OIK-NJ99', 'SAKR-2RTY-8UIO-BV00', 'SAKR-5FGH-7JKL-MN11',
  'SAKR-3ZXC-9VBN-PO22', 'SAKR-1ASD-8QWE-RT33', 'SAKR-9DFG-2HJK-LK44', 'SAKR-7TYU-5IOP-MN55',
  'SAKR-4QAZ-6WSX-ED66', 'SAKR-8EDC-3RFV-TG77', 'SAKR-2YHN-9UJM-IK88', 'SAKR-6OLP-5KMN-JI99',
  'SAKR-3BVC-1XZA-QW10', 'SAKR-7ERT-4DFG-HJ21', 'SAKR-8IKL-9OPM-NB32', 'SAKR-5ZXC-2VBN-AS43',
  'SAKR-1QWE-3RTY-UI54', 'SAKR-9FGH-6JKL-OP65', 'SAKR-7MNB-8VCX-ZA76', 'SAKR-2SDX-4FRT-GB87',
  'SAKR-3HYU-9JIK-LO98', 'SAKR-6POM-1NBV-QA09', 'SAKR-8WER-2TYU-IS10', 'SAKR-4DFG-5HJK-LM21',
  'SAKR-9ZXC-7VBN-OP32', 'SAKR-1ASQ-3WED-RF43', 'SAKR-2TGY-6HUJ-IK54', 'SAKR-8OLP-9KMN-NB65',
  'SAKR-4QAZ-5WSX-ED76', 'SAKR-3RFV-7TGB-YH87', 'SAKR-6UJM-8IKN-LO98', 'SAKR-9PLM-2OKN-JI09',
  'SAKR-1BVX-3CZA-QW10'
]);

const getCurrentDateString = () => new Date().toISOString().split('T')[0];

const getInitialSubscription = (): Subscription => {
  try {
    const item = window.localStorage.getItem('subscription');
    if (item) {
      const parsed = JSON.parse(item) as Subscription;
      // Basic validation and check for expiry
      if (typeof parsed.isActive === 'boolean' && typeof parsed.plan === 'string') {
        if (parsed.expiryDate && new Date().getTime() > parsed.expiryDate) {
          // Subscription has expired
          const expiredSub: Subscription = { isActive: false, plan: 'free' };
          window.localStorage.setItem('subscription', JSON.stringify(expiredSub));
          return expiredSub;
        }
        return parsed;
      }
    }
  } catch (error) {
    console.error('Error reading subscription from localStorage', error);
  }
  return { isActive: false, plan: 'free' };
};

const getInitialDailyUsage = (): { date: string; count: number } => {
    try {
        const item = window.localStorage.getItem('dailyUsage');
        if (item) {
            const parsed = JSON.parse(item);
            if (parsed.date === getCurrentDateString()) {
                return parsed;
            }
        }
    } catch (error) {
        console.error('Error reading daily usage from localStorage', error);
    }
    // If no usage found, or date is old, reset it.
    return { date: getCurrentDateString(), count: 0 };
}

export const useSubscription = (onLimitReached: () => void): SubscriptionHook => {
  const [subscription, setSubscription] = useState(getInitialSubscription);
  const [dailyUsage, setDailyUsage] = useState(getInitialDailyUsage);

  useEffect(() => {
    localStorage.setItem('subscription', JSON.stringify(subscription));
  }, [subscription]);

  useEffect(() => {
    localStorage.setItem('dailyUsage', JSON.stringify(dailyUsage));
  }, [dailyUsage]);

  const checkAccess = useCallback(() => {
    const isPremium = subscription.isActive && subscription.plan === 'premium' && 
                      (!subscription.expiryDate || new Date().getTime() < subscription.expiryDate);
    
    if (isPremium) {
      return true;
    }
    
    // Refresh usage state in case date changed
    const today = getCurrentDateString();
    let currentUsage = dailyUsage;
    if (dailyUsage.date !== today) {
        currentUsage = { date: today, count: 0 };
        setDailyUsage(currentUsage);
    }

    if (currentUsage.count >= DAILY_FREE_LIMIT) {
      onLimitReached();
      return false;
    }
    
    const newUsage = { ...currentUsage, count: currentUsage.count + 1 };
    setDailyUsage(newUsage);
    return true;
  }, [subscription, dailyUsage, onLimitReached]);

  const activate = (code: string): { success: boolean; message: string } => {
    try {
        if (!PREDEFINED_CODES.has(code)) {
            return { success: false, message: 'Code is invalid or has already been used.' };
        }

        const usedCodesStr = localStorage.getItem('usedActivationCodes');
        const usedCodes: string[] = usedCodesStr ? JSON.parse(usedCodesStr) : [];
        
        if (usedCodes.includes(code)) {
            return { success: false, message: 'Code is invalid or has already been used.' };
        }

        // Mark code as used for this device
        usedCodes.push(code);
        localStorage.setItem('usedActivationCodes', JSON.stringify(usedCodes));
        
        const expiryDate = new Date().getTime() + 30 * 24 * 60 * 60 * 1000; // 30 days
        setSubscription({ isActive: true, plan: 'premium', expiryDate });
        return { success: true, message: 'Activation successful!' };

    } catch (error) {
        console.error("Error activating code:", error);
        return { success: false, message: 'An unexpected error occurred.' };
    }
  };
  
  const getUsage = () => ({
      used: dailyUsage.count,
      limit: DAILY_FREE_LIMIT,
  });

  return { subscription, checkAccess, activate, getUsage };
};