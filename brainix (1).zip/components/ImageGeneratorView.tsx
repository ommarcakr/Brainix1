// FIX: Added full content for components/ImageGeneratorView.tsx
import React, { useState } from 'react';
import { Language } from '../types';
import { TRANSLATIONS } from '../constants';
import { generateImage } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';

interface ImageGeneratorViewProps {
  language: Language;
  checkAccess: () => boolean;
}

const ImageGeneratorView: React.FC<ImageGeneratorViewProps> = ({ language, checkAccess }) => {
  const t = TRANSLATIONS[language];
  const [prompt, setPrompt] = useState('');
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!prompt.trim() || isLoading) return;
    if (!checkAccess()) return;

    setIsLoading(true);
    setImageUrl(null);
    setError(null);
    try {
      const result = await generateImage(prompt);
      if (result) {
        setImageUrl(result);
      } else {
        setError("Failed to generate image. The model may have refused the prompt.");
      }
    } catch (err) {
      setError("An error occurred while generating the image.");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full items-center">
      <div className="w-full max-w-3xl p-4">
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleGenerate()}
            placeholder={t.enterPromptHere}
            className="flex-grow p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
            disabled={isLoading}
          />
          <button
            onClick={handleGenerate}
            disabled={isLoading || !prompt.trim()}
            className="px-6 py-3 bg-primary-500 text-white font-semibold rounded-lg hover:bg-primary-600 disabled:bg-primary-300"
          >
            {isLoading ? t.generating : t.generate}
          </button>
        </div>
      </div>
      <div className="flex-1 flex justify-center items-center w-full p-4">
        <div className="w-full max-w-xl aspect-square bg-gray-200 dark:bg-gray-800 rounded-lg flex justify-center items-center overflow-hidden">
          {isLoading && <LoadingSpinner />}
          {error && <p className="text-red-500 p-4 text-center">{error}</p>}
          {imageUrl && !isLoading && <img src={imageUrl} alt={prompt} className="w-full h-full object-contain" />}
          {!isLoading && !imageUrl && !error && <p className="text-gray-500">{t.imageHeader}</p>}
        </div>
      </div>
    </div>
  );
};

export default ImageGeneratorView;