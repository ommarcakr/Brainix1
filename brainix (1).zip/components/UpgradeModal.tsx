// FIX: Added full content for components/UpgradeModal.tsx
import React, { useState } from 'react';
import { Language, SubscriptionHook } from '../types';
import { TRANSLATIONS } from '../constants';

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  subscription: SubscriptionHook;
}

const UpgradeModal: React.FC<UpgradeModalProps> = ({ isOpen, onClose, language, subscription }) => {
  if (!isOpen) return null;

  const t = TRANSLATIONS[language];
  const [activationCode, setActivationCode] = useState('');
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleActivate = () => {
    const result = subscription.activate(activationCode.trim());
    if (result.success) {
      setMessage({ type: 'success', text: t.upgradeSuccess });
      setTimeout(() => {
        onClose();
        setMessage(null);
        setActivationCode('');
      }, 2000);
    } else {
      setMessage({ type: 'error', text: t.invalidCode });
    }
  };

  const isPremium = subscription.subscription.isActive && subscription.subscription.plan === 'premium';
  const usage = subscription.getUsage();
  const remainingUses = usage.limit - usage.used;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 transition-opacity">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-6 w-full max-w-md m-4 relative">
        <button onClick={onClose} className="absolute top-3 right-3 text-gray-500 hover:text-gray-800 dark:hover:text-gray-200 text-2xl font-bold">
          &times;
        </button>
        
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">
          {isPremium ? t.manageSubscription : t.upgradeToPremium}
        </h2>
        
        {isPremium ? (
          <div>
            <p className="text-gray-600 dark:text-gray-300 mb-2">{t.currentPlan}: <span className="font-semibold text-green-500">{t.premium}</span></p>
            {subscription.subscription.expiryDate && (
                <p className="text-sm text-gray-500 dark:text-gray-400">
                    {t.activeUntil}: {new Date(subscription.subscription.expiryDate).toLocaleDateString()}
                </p>
            )}
          </div>
        ) : (
            <>
                <p className="text-gray-600 dark:text-gray-300 mb-4">{t.unlockFeatures}</p>
                <div className="bg-gray-100 dark:bg-gray-700 p-3 rounded-lg mb-6 text-center">
                    <p className="font-semibold text-gray-800 dark:text-white">{t.dailyUsage}</p>
                    <p className="text-2xl font-bold text-primary-500">{remainingUses > 0 ? remainingUses : 0} / {usage.limit}</p>
                </div>
        
                <div className="mb-6">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t.enterActivationCode}</label>
                    <div className="flex gap-2">
                        <input
                            type="text"
                            value={activationCode}
                            onChange={(e) => {
                                setActivationCode(e.target.value);
                                setMessage(null);
                            }}
                            placeholder="BRAINIX-XXXXXXXX"
                            className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-primary-500"
                        />
                        <button
                            onClick={handleActivate}
                            className="px-6 py-2 bg-primary-500 text-white font-semibold rounded-lg hover:bg-primary-600 disabled:bg-primary-300"
                            disabled={!activationCode.trim()}
                        >
                            {t.activate}
                        </button>
                    </div>
                    {message && (
                        <p className={`mt-2 text-sm ${message.type === 'success' ? 'text-green-500' : 'text-red-500'}`}>
                            {message.text}
                        </p>
                    )}
                </div>

                <div>
                    <h3 className="font-semibold text-gray-700 dark:text-gray-300 mb-2">{t.premiumFeatures}</h3>
                    <ul className="list-disc list-inside text-gray-600 dark:text-gray-300 space-y-1">
                        <li>{t.feature1}</li>
                        <li>{t.feature2}</li>
                        <li>{t.feature3}</li>
                    </ul>
                </div>
            </>
        )}
      </div>
    </div>
  );
};

export default UpgradeModal;