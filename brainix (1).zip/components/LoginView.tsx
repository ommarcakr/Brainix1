import React, { useEffect } from 'react';
import { Language, User } from '../types';
import { TRANSLATIONS } from '../constants';

interface LoginViewProps {
  onLogin: (user: User) => void;
  language: Language;
}

const LoginView: React.FC<LoginViewProps> = ({ onLogin, language }) => {
  const t = TRANSLATIONS[language];

  // This is a PLACEHOLDER. You MUST replace it with your own Client ID from Google Cloud Console.
  const GOOGLE_CLIENT_ID = "1234567890-abcdefghijklmnopqrstuvwxyz.apps.googleusercontent.com";
  
  const isPlaceholderClientId = GOOGLE_CLIENT_ID.startsWith("1234567890");

  useEffect(() => {
    if (isPlaceholderClientId) {
      console.error("FATAL: Google Client ID is still the placeholder. Please replace it with a real one in components/LoginView.tsx.");
      return; // Do not attempt to initialize Google Sign-In with a fake ID
    }

    if (!(window as any).google || !(window as any).google.accounts) {
      console.warn("Google Identity Services script not loaded yet.");
      return;
    }

    const handleCallbackResponse = (response: any) => {
      try {
        const userObject = JSON.parse(atob(response.credential.split('.')[1]));
        const loggedInUser: User = {
          name: userObject.name,
          email: userObject.email,
          picture: userObject.picture,
        };
        onLogin(loggedInUser);
      } catch (e) {
        console.error("Error decoding JWT token:", e);
      }
    };

    try {
        (window as any).google.accounts.id.initialize({
          client_id: GOOGLE_CLIENT_ID,
          callback: handleCallbackResponse,
        });

        (window as any).google.accounts.id.renderButton(
          document.getElementById('signInButtonContainer'),
          { 
            theme: 'outline', 
            size: 'large', 
            type: 'standard', 
            text: 'signin_with', 
            shape: 'pill',
            logo_alignment: 'left',
          }
        );
    } catch (error) {
        console.error("Error initializing Google Sign-In:", error);
    }
  }, [onLogin, language, isPlaceholderClientId]);

  return (
    <div className="flex flex-col items-center justify-center h-screen w-screen bg-gray-100 dark:bg-gray-900">
      <div className="text-center p-8 bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-sm w-full">
        <h1 className="text-4xl font-bold text-primary-500 mb-2">Brainix</h1>
        <p className="text-lg text-gray-600 dark:text-gray-300 mb-8">{t.welcomeTo} Brainix</p>
        
        {isPlaceholderClientId ? (
          <div className="text-red-500 bg-red-100 dark:bg-red-900/50 p-4 rounded-lg text-sm text-left rtl:text-right">
            <h3 className="font-bold mb-2">
              {language === 'ar' ? 'خطأ في الإعداد' : 'Configuration Error'}
            </h3>
            <p>
              {language === 'ar' 
                ? 'يجب استبدال Google Client ID التجريبي بالمعرّف الحقيقي الخاص بك لجعل تسجيل الدخول يعمل.' 
                : 'The placeholder Google Client ID must be replaced with your real one for login to work.'}
            </p>
            <p className="mt-2 font-semibold">
              {language === 'ar' 
                ? 'الخطوات:' 
                : 'Steps:'}
            </p>
            <ol className="list-decimal list-inside">
              <li>{language === 'ar' ? 'اذهب إلى Google Cloud Console.' : 'Go to Google Cloud Console.'}</li>
              <li>{language === 'ar' ? 'أنشئ "OAuth 2.0 Client ID" لتطبيق ويب.' : 'Create an "OAuth 2.0 Client ID" for a Web Application.'}</li>
              <li>{language === 'ar' ? 'انسخ المعرّف وألصقه بدلاً من المعرّف التجريبي في ملف `components/LoginView.tsx`.' : 'Copy the ID and paste it over the placeholder ID in `components/LoginView.tsx`.'}</li>
            </ol>
            <a href="https://console.cloud.google.com/apis/credentials" target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline mt-3 inline-block font-semibold">
               {language === 'ar' ? 'اذهب إلى Google Console الآن' : 'Go to Google Console Now'}
            </a>
          </div>
        ) : (
          <div id="signInButtonContainer" className="flex justify-center min-h-[40px]"></div>
        )}
      </div>
    </div>
  );
};

export default LoginView;
