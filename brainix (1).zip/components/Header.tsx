import React from 'react';
import { AppMode, Language } from '../types';
import { TRANSLATIONS } from '../constants';

interface HeaderProps {
  mode: AppMode;
  language: Language;
}

const Header: React.FC<HeaderProps> = ({ mode, language }) => {
  const t = TRANSLATIONS[language];

  const headers: Record<AppMode, string> = {
    chat: t.chatHeader,
    image: t.imageHeader,
    code: t.codeHeader,
    plan: t.planHeader,
    search: t.searchHeader,
    contextual: t.contextualHeader,
    admin: t.adminHeader,
  };

  return (
    <header className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center">
      <h2 className="text-xl font-semibold text-gray-800 dark:text-white">{headers[mode]}</h2>
    </header>
  );
};

export default Header;