
import React, { useState, useEffect } from 'react';
import { Language } from '../types';
import { TRANSLATIONS } from '../constants';
import { ClipboardIcon, ClipboardCheckIcon } from './icons';

interface AdminViewProps {
  language: Language;
}

const AdminView: React.FC<AdminViewProps> = ({ language }) => {
  const t = TRANSLATIONS[language];
  const [codes, setCodes] = useState<Record<string, boolean>>({});
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  useEffect(() => {
    const storedCodes = localStorage.getItem('activationCodes');
    if (storedCodes) {
      setCodes(JSON.parse(storedCodes));
    }
  }, []);

  const generateCode = () => {
    const newCode = `BRAINIX-${crypto.randomUUID().toUpperCase().slice(0, 8)}`;
    const newCodes = { ...codes, [newCode]: true }; // true means available
    setCodes(newCodes);
    localStorage.setItem('activationCodes', JSON.stringify(newCodes));
  };

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 p-4 sm:p-6 lg:p-8">
      <div className="max-w-4xl mx-auto bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
        <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
            {t.adminHeader}
            </h2>
            <a href="#" className="text-sm text-primary-500 hover:underline">{language === 'ar' ? 'الخروج' : 'Logout'}</a>
        </div>
       
        <div className="mb-8">
            <button
                onClick={generateCode}
                className="px-5 py-2 bg-primary-500 text-white font-semibold rounded-lg hover:bg-primary-600"
            >
                {t.generateNewCode}
            </button>
        </div>

        <div>
            <h3 className="text-xl font-semibold text-gray-700 dark:text-gray-300 mb-4">{t.activationCodes}</h3>
            <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-2">
                {Object.entries(codes).length === 0 ? (
                    <p className="text-gray-500">{language === 'ar' ? 'لا توجد أكواد بعد.' : 'No codes yet.'}</p>
                ) : (
                    Object.entries(codes).map(([code, isAvailable]) => (
                        <div key={code} className="flex items-center justify-between bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                            <span className={`font-mono text-sm ${isAvailable ? 'text-gray-800 dark:text-gray-200' : 'text-gray-400 dark:text-gray-500 line-through'}`}>
                                {code}
                            </span>
                            <div className="flex items-center gap-4">
                                <span className={`px-2 py-1 text-xs font-semibold rounded-full ${isAvailable ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'}`}>
                                    {isAvailable ? (language === 'ar' ? 'متاح' : 'Available') : (language === 'ar' ? 'مستخدم' : 'Used')}
                                </span>
                                <button onClick={() => handleCopy(code)} className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200">
                                    {copiedCode === code ? <ClipboardCheckIcon className="w-5 h-5 text-green-500"/> : <ClipboardIcon className="w-5 h-5"/>}
                                </button>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
      </div>
    </div>
  );
};

export default AdminView;
