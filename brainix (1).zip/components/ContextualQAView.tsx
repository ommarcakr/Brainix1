// FIX: Added full content for components/ContextualQAView.tsx
import React, { useState, useCallback } from 'react';
import { Language } from '../types';
import { TRANSLATIONS } from '../constants';
import { generateAnswerFromContext } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';
import { useDropzone } from 'react-dropzone';
import Markdown from 'react-markdown';

interface ContextualQAViewProps {
  language: Language;
  checkAccess: () => boolean;
}

const fileToBase64 = (file: File): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve((reader.result as string).split(',')[1]);
    reader.onerror = (error) => reject(error);
  });

const ContextualQAView: React.FC<ContextualQAViewProps> = ({ language, checkAccess }) => {
  const t = TRANSLATIONS[language];
  const [textContext, setTextContext] = useState('');
  const [imageContext, setImageContext] = useState<{ file: File; preview: string; data: string; mimeType: string } | null>(null);
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (file) {
      const data = await fileToBase64(file);
      setImageContext({
        file,
        preview: URL.createObjectURL(file),
        data,
        mimeType: file.type,
      });
      setTextContext(''); // Clear text context if image is uploaded
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ onDrop, accept: { 'image/*': [] }, multiple: false });

  const handleAsk = async () => {
    if (!question.trim() || isLoading || (!textContext.trim() && !imageContext)) return;
    if (!checkAccess()) return;

    setIsLoading(true);
    setAnswer('');
    setError(null);
    try {
      const context = {
        text: textContext,
        image: imageContext ? { data: imageContext.data, mimeType: imageContext.mimeType } : undefined,
      };
      const response = await generateAnswerFromContext(question, context);
      setAnswer(response);
    } catch (err) {
      setError("An error occurred while generating the answer.");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleRemoveImage = () => {
      if (imageContext) {
        URL.revokeObjectURL(imageContext.preview);
        setImageContext(null);
      }
  }

  return (
    <div className="flex flex-col h-full">
        <div className="p-4 flex-1 overflow-y-auto">
            <h3 className="font-semibold mb-2 text-gray-700 dark:text-gray-300">Context</h3>
            {imageContext ? (
                <div className="relative w-full max-w-md">
                    <img src={imageContext.preview} alt="Context" className="rounded-lg max-h-64"/>
                    <button onClick={handleRemoveImage} className="absolute top-2 right-2 bg-black/50 text-white rounded-full p-1">&times;</button>
                </div>
            ) : (
                <>
                    <textarea
                        value={textContext}
                        onChange={(e) => setTextContext(e.target.value)}
                        placeholder={t.pasteTextContext}
                        className="w-full h-32 p-2 border rounded-lg mb-2 dark:bg-gray-800 dark:border-gray-600"
                        disabled={!!imageContext}
                    />
                    <div className="text-center my-2 text-gray-500">{t.or}</div>
                    <div {...getRootProps()} className={`p-6 border-2 border-dashed rounded-lg cursor-pointer text-center ${isDragActive ? 'border-primary-500 bg-primary-50 dark:bg-primary-900/20' : 'border-gray-300 dark:border-gray-600'}`}>
                        <input {...getInputProps()} />
                        <p>{t.uploadAnImage}</p>
                    </div>
                </>
            )}

            <div className="mt-6">
                <h3 className="font-semibold mb-2 text-gray-700 dark:text-gray-300">Answer</h3>
                {isLoading ? <LoadingSpinner /> : (
                    error ? <p className="text-red-500">{error}</p> : (
                        answer ? <div className="prose dark:prose-invert max-w-none bg-gray-100 dark:bg-gray-800 p-4 rounded-lg"><Markdown>{answer}</Markdown></div> : <p className="text-gray-400">Your answer will appear here.</p>
                    )
                )}
            </div>
        </div>
        <div className="p-4 border-t dark:border-gray-700">
            <div className="flex gap-2">
                <input
                    type="text"
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleAsk()}
                    placeholder={t.askAQuestion}
                    className="flex-grow p-3 border rounded-lg dark:bg-gray-800 dark:border-gray-600"
                    disabled={isLoading}
                />
                <button
                    onClick={handleAsk}
                    disabled={isLoading || !question.trim() || (!textContext.trim() && !imageContext)}
                    className="px-6 py-3 bg-primary-500 text-white font-semibold rounded-lg hover:bg-primary-600 disabled:bg-primary-300"
                >
                    {t.generate}
                </button>
            </div>
        </div>
    </div>
  );
};

export default ContextualQAView;