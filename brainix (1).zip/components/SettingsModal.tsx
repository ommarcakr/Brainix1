import React from 'react';
import { Language, Theme } from '../types';
import { TRANSLATIONS } from '../constants';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  theme: Theme;
  setTheme: (theme: Theme) => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, language, setLanguage, theme, setTheme }) => {
  if (!isOpen) return null;
  const t = TRANSLATIONS[language];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-50 transition-opacity">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl p-6 w-full max-w-md m-4">
        <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">{t.settings}</h2>
        
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t.language}</label>
            <select
              value={language}
              onChange={(e) => setLanguage(e.target.value as Language)}
              className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-md bg-white dark:bg-gray-700 text-gray-800 dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-primary-500"
            >
              <option value="en">English</option>
              <option value="ar">العربية</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">{t.theme}</label>
            <div className="flex space-x-4">
              <button
                onClick={() => setTheme('light')}
                className={`flex-1 p-2 rounded-md border transition-colors ${theme === 'light' ? 'bg-primary-500 text-white border-primary-500' : 'bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600'}`}
              >
                {t.light}
              </button>
              <button
                onClick={() => setTheme('dark')}
                className={`flex-1 p-2 rounded-md border transition-colors ${theme === 'dark' ? 'bg-primary-500 text-white border-primary-500' : 'bg-gray-100 dark:bg-gray-700 border-gray-300 dark:border-gray-600'}`}
              >
                {t.dark}
              </button>
            </div>
          </div>
        </div>

        <div className="mt-8 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-primary-500 text-white font-semibold rounded-lg hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
          >
            {t.save}
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;