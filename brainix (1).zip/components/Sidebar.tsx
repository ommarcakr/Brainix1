
import React from 'react';
import { AppMode, Language } from '../types';
import { ChatIcon, CodeIcon, ImageIcon, PlanIcon, SearchIcon, SettingsIcon, ContextualIcon } from './icons';

interface SidebarProps {
  mode: AppMode;
  setMode: (mode: AppMode) => void;
  onSettingsClick: () => void;
  language: Language;
}

const Sidebar: React.FC<SidebarProps> = ({ mode, setMode, onSettingsClick, language }) => {
  const isRtl = language === 'ar';
  
  const navItems: { id: AppMode; icon: React.FC<any>; label: string }[] = [
    { id: 'chat', icon: ChatIcon, label: 'Chat' },
    { id: 'image', icon: ImageIcon, label: 'Image' },
    { id: 'code', icon: CodeIcon, label: 'Code' },
    { id: 'plan', icon: PlanIcon, label: 'Plan' },
    { id: 'search', icon: SearchIcon, label: 'Search' },
    { id: 'contextual', icon: ContextualIcon, label: 'Q&A' },
  ];

  return (
    <div className={`flex flex-col h-full bg-white dark:bg-gray-800 border-r dark:border-gray-700 text-gray-700 dark:text-gray-200 p-4 transition-all duration-300 ${isRtl ? 'border-l' : 'border-r'}`}>
      <div className="flex items-center mb-10">
        <div className="p-2 bg-primary-500 rounded-lg text-white font-bold text-2xl flex-shrink-0">B</div>
        <h1 className={`text-2xl font-bold truncate ${isRtl ? 'mr-3' : 'ml-3'}`}>Brainix</h1>
      </div>

      <nav className="flex-1 space-y-2">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setMode(item.id)}
            className={`w-full flex items-center p-3 rounded-lg transition-colors text-left ${
              mode === item.id
                ? 'bg-primary-500 text-white shadow'
                : 'hover:bg-gray-100 dark:hover:bg-gray-700'
            }`}
          >
            <item.icon className="w-6 h-6 flex-shrink-0" />
            <span className={`font-medium ${isRtl ? 'mr-4' : 'ml-4'}`}>{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="mt-auto flex flex-col space-y-2">
        <button onClick={onSettingsClick} className={`w-full flex items-center p-3 rounded-lg transition-colors text-left hover:bg-gray-100 dark:hover:bg-gray-700`}>
           <SettingsIcon className="w-6 h-6 flex-shrink-0" />
           <span className={`font-medium ${isRtl ? 'mr-4' : 'ml-4'}`}>Settings</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;
