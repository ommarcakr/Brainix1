// FIX: Added full content for components/CodeGeneratorView.tsx
import React, { useState } from 'react';
import { Language } from '../types';
import { TRANSLATIONS } from '../constants';
import { generateCode } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';
import { ClipboardIcon, ClipboardCheckIcon } from './icons';

interface CodeGeneratorViewProps {
  language: Language;
  checkAccess: () => boolean;
}

const CodeGeneratorView: React.FC<CodeGeneratorViewProps> = ({ language, checkAccess }) => {
  const t = TRANSLATIONS[language];
  const [prompt, setPrompt] = useState('');
  const [code, setCode] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isCopied, setIsCopied] = useState(false);

  const handleGenerate = async () => {
    if (!prompt.trim() || isLoading) return;
    if (!checkAccess()) return;

    setIsLoading(true);
    setCode('');
    setError(null);
    try {
      const result = await generateCode(prompt);
      setCode(result);
    } catch (err) {
      setError("An error occurred while generating the code.");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleCopy = () => {
    if (!code) return;
    navigator.clipboard.writeText(code);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleGenerate()}
            placeholder={t.enterPromptHere}
            className="flex-grow p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
            disabled={isLoading}
          />
          <button
            onClick={handleGenerate}
            disabled={isLoading || !prompt.trim()}
            className="px-6 py-3 bg-primary-500 text-white font-semibold rounded-lg hover:bg-primary-600 disabled:bg-primary-300"
          >
            {isLoading ? t.generating : t.generate}
          </button>
        </div>
      </div>
      <div className="flex-1 p-4 overflow-y-auto relative">
        {isLoading && (
            <div className="absolute inset-0 flex justify-center items-center bg-white/50 dark:bg-gray-900/50">
                <LoadingSpinner />
            </div>
        )}
        {error && <p className="text-red-500 p-4 text-center">{error}</p>}
        {code && (
            <div className="relative">
                <button onClick={handleCopy} className="absolute top-2 right-2 p-2 bg-gray-200 dark:bg-gray-700 rounded-md hover:bg-gray-300 dark:hover:bg-gray-600">
                    {isCopied ? <ClipboardCheckIcon className="w-5 h-5 text-green-500"/> : <ClipboardIcon className="w-5 h-5"/>}
                </button>
                <pre className="bg-gray-100 dark:bg-gray-800 p-4 rounded-lg overflow-x-auto">
                    <code className="text-sm text-gray-800 dark:text-gray-200">{code}</code>
                </pre>
            </div>
        )}
      </div>
    </div>
  );
};

export default CodeGeneratorView;