// FIX: Added full content for components/SearchView.tsx
import React, { useState } from 'react';
import { Language, Source } from '../types';
import { TRANSLATIONS } from '../constants';
import { searchWeb } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';
import Markdown from 'react-markdown';

interface SearchViewProps {
  language: Language;
  checkAccess: () => boolean;
}

const SearchView: React.FC<SearchViewProps> = ({ language, checkAccess }) => {
  const t = TRANSLATIONS[language];
  const [prompt, setPrompt] = useState('');
  const [result, setResult] = useState<{text: string; sources: Source[]} | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async () => {
    if (!prompt.trim() || isLoading) return;
    if (!checkAccess()) return;

    setIsLoading(true);
    setResult(null);
    setError(null);
    try {
      const response = await searchWeb(prompt);
      setResult(response);
    } catch (err) {
      setError("An error occurred while searching the web.");
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            placeholder={t.searchTheWeb}
            className="flex-grow p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
            disabled={isLoading}
          />
          <button
            onClick={handleSearch}
            disabled={isLoading || !prompt.trim()}
            className="px-6 py-3 bg-primary-500 text-white font-semibold rounded-lg hover:bg-primary-600 disabled:bg-primary-300"
          >
            {isLoading ? t.generating : 'Search'}
          </button>
        </div>
      </div>
      <div className="flex-1 p-4 overflow-y-auto">
        {isLoading && <div className="flex justify-center items-center h-full"><LoadingSpinner /></div>}
        {error && <p className="text-red-500 p-4 text-center">{error}</p>}
        {result && (
          <div>
            <div className="prose dark:prose-invert max-w-none mb-6">
                <Markdown>{result.text}</Markdown>
            </div>
            {result.sources.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold mb-2">{t.sources}</h3>
                <ul className="space-y-2">
                  {result.sources.map((source, index) => (
                    <li key={index} className="text-sm">
                      <a href={source.uri} target="_blank" rel="noopener noreferrer" className="text-primary-500 hover:underline break-all">
                        {source.title || source.uri}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default SearchView;