// FIX: Added full content for components/ChatView.tsx
import React, { useState, useRef, useEffect } from 'react';
import { Language, HistoryItem } from '../types';
import { TRANSLATIONS } from '../constants';
import { generateText } from '../services/geminiService';
import LoadingSpinner from './LoadingSpinner';
import Markdown from 'react-markdown';

interface ChatViewProps {
  language: Language;
  checkAccess: () => boolean;
}

const ChatView: React.FC<ChatViewProps> = ({ language, checkAccess }) => {
  const t = TRANSLATIONS[language];
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [prompt, setPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [history]);

  const handleSend = async () => {
    if (!prompt.trim() || isLoading) return;
    if (!checkAccess()) return;

    const userMessage: HistoryItem = { role: 'user', parts: [{ text: prompt }] };
    setHistory(prev => [...prev, userMessage]);
    setPrompt('');
    setIsLoading(true);

    try {
      const geminiHistory = history.map(h => ({
        role: h.role,
        parts: h.parts.map(p => ({ text: p.text })),
      }));
      const responseText = await generateText(prompt, geminiHistory);
      const modelMessage: HistoryItem = { role: 'model', parts: [{ text: responseText }] };
      setHistory(prev => [...prev, modelMessage]);
    } catch (error) {
      console.error(error);
      const errorMessage: HistoryItem = { role: 'model', parts: [{ text: "Sorry, I couldn't get a response. Please try again." }] };
      setHistory(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {history.map((item, index) => (
          <div key={index} className={`flex ${item.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-xl lg:max-w-2xl px-4 py-2 rounded-lg ${item.role === 'user' ? 'bg-primary-500 text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white'}`}>
              <div className="prose dark:prose-invert max-w-none">
                <Markdown>{item.parts[0].text}</Markdown>
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
             <div className="max-w-lg px-4 py-2 rounded-lg bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-white">
                <LoadingSpinner />
             </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>
      <div className="p-4 border-t border-gray-200 dark:border-gray-700">
        <div className="relative">
          <input
            type="text"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
            placeholder={t.sendMessage}
            className="w-full p-3 pr-12 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-800 dark:text-white focus:outline-none focus:ring-2 focus:ring-primary-500"
            disabled={isLoading}
          />
          <button
            onClick={handleSend}
            disabled={isLoading || !prompt.trim()}
            className="absolute inset-y-0 right-0 flex items-center justify-center w-12 text-primary-500 hover:text-primary-600 disabled:text-gray-400"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatView;